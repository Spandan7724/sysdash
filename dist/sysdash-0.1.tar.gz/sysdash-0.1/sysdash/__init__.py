from .sysdash import get_cpu_info, get_memory_info, get_disk_info, get_uptime, get_gpu_info, get_system_info
